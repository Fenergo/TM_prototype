
  # Transaction Monitoring Platform Blueprint

  This is a code bundle for Transaction Monitoring Platform Blueprint. The original project is available at https://www.figma.com/design/LHnGGkW92rGKv88aTevWbx/Transaction-Monitoring-Platform-Blueprint.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  